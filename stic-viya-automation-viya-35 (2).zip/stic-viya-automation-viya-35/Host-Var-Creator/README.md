# Host Var Creator

### This playbook creates all the <inventory_name>.yml files under host_vars for a multi NIC/IP environment.

## Usage
In the sas_viya_playbook directory

ansible-playbook stic-viya-automation/Host-Var-Creator/host-var-creator.yml

