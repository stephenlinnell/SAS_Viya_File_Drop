### RMSS Post Installation v 1.3
Currently the US STIC team leads all RMSS installations prior to a handoff to an administration team here at SAS.  These scripts follow the handoff checklist provided by the admin teams to be completed before the transition to service.

#### Supported Systems
* SAS Viya 3.5 on RHEL 7.x
* Ansible 2.7.x-2.9.x

#### Automated Processes 
* Creation of SAS Work Cron Jobs
* Verification of Elasticsearch
* SASv9 file configuration
* Yum repository disable
* Information Gathering
* Compute Server Temp Path Configuration
* Creation of Log Cleanup Cron Jobs
* sasv9 file validation


Expected processes in future releases 
* RabbitMQ password reset
* SASBoot password reset
* Initial user password reset disable

    
### Usage
The production branch should be downloaded and unzipped in your sas_viya_playbook
directory.  The following are sample commands to use.
#### User with Passwordless SSH and Passwordless SUDO
    ansible-playbook ./stic-viya-automation-prod/RMSS-Post-Install/viya_post_install.yml
#### User without passwordless SSH and Passwordless SUDO
    ansible-playbook ./stic-viya-automation-prod/RMSS-Post-Install/viya_post_install.yml -Kk
* **Note the following flags represent the following**
    - **-K** --> user requiring SUDO password
    - **-k** --> user requiring SSH password. CURRENT DEFECT (https://github.com/ansible/ansible/issues/56629)
  

### Notes
* If saswork location does not exist no jobs will be created, warnings will be issued for saswork locations with restricted permissions
* If elasticsearch is not present in your deployment, the processes will be skipped
* Information will be obtained from each host in the deployment, that is defined in inventory.ini

### Output
After sucessful run of the playbook the following will be present in a tar directory
* cron_files - A directory with cron files with the saswork clean job entered (if location exists) from each programming host and the Log cron job from each CAS host
* elasticsearc_status - A directory with text files containing the current status of elasticsearch (if present) from each elasticsearch host
* sasv9s - A directory with the completed SASV9 file frome each programming host (validation of this is TBC in next version)
* yum_disable_files - A directory with the yum repository definitions which will show each sas repo has been disabled (from each host)
* comp_srv_files - A directory with the sas-compsrv files with configuration completed for Temp Path
* info_files - A  directory with the following information from each host
    * Basic Host Information - # of Cores, Memory Size, Hostname, IP.
    * RPM's installed on each host 
    * SAS Services running on each host
    * SAS Viya Identities Configuration 
    * SAS Viya URLs active
