# GHUSPS - US STIC Automation Scripts
## This repository contains scripts to streamline post-installation processes for SAS Consultants 



### RMSS Post Installation v 1.3
Currently the US STIC team leads all RMSS installations prior to a handoff to an administration team here at SAS.  These scripts follow the handoff checklist provided by the admin teams to be completed before the transition to service.  See the README.md file in RMSS-Post-Install directory for more


### Host Variable Creator v 1.0
This playbook will automate creating host_var files for a SAS Viya 3.5 deployment on Linux.  This will help with systems that have more thant one NIC or IP/Hostname